﻿namespace Grade_Calculator2_Shelby_Watson
{
    internal class list<T>
    {
    }
}